package com.demo.comentoStatistic.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NonHolidayDto {
    Integer totCnt;
}
