package com.demo.comentoStatistic.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class YearMonthCountDto {
    String yearMonth;
    Integer totCnt;
}
