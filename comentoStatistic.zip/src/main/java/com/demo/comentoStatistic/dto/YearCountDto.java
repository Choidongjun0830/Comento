package com.demo.comentoStatistic.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class YearCountDto {
    String year;
    Integer totCnt;
}
